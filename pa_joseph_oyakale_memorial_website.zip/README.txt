PA JOSEPH AJIBADE OYAKALE MEMORIAL WEBSITE

This folder contains the prepared memorial webpage.

IMPORTANT:
1. Open index.html to preview the page.
2. Before publishing, replace TRIBUTE_FORM_URL_HERE with the URL of a Google Form (or another public tribute form) where family and friends can submit their names, messages and photographs.
3. Publish the page using GitHub Pages or another static website host.
4. Once you have the public website URL, create a Bitly short link such as:
   bit.ly/pa-joseph-oyakale
   or
   bit.ly/memorial-joseph-oyakale
   subject to availability.

The memorial page is designed to be mobile-friendly and shareable on Facebook and WhatsApp.
